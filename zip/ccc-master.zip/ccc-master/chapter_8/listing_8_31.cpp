#include <cstdio>

int main() {
luke:
  printf("I'm not afraid.\n");
yoda:
  printf("You will be.");
}
