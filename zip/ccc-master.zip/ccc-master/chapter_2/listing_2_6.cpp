#include <cstdio>

int main() {
  printf(" 7 ==  7: %d\n", 7 == 7);
  printf(" 7 !=  7: %d\n", 7 != 7);
  printf("10 >  20: %d\n", 10 > 20);
  printf("10 >= 20: %d\n", 10 >= 20);
  printf("10 <  20: %d\n", 10 < 20);
  printf("20 <= 20: %d\n", 20 <= 20);
}
